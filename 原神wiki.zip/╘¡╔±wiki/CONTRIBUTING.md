# amWiki 贡献指引

- 如果您是 coder，您的所有 issues 或 pull requests，请在[Github项目托管地址](https://github.com/TevinLi/amWiki)提交  
- 如果您需要直接提问或建议，请加QQ群347125653