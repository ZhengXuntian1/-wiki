# amWiki 功能导图

![amWiki功能导图](https://amwiki.xf09.net/docs/assets/mapping.png)  

**说明**：灰色文字代表的功能部分，表示目前版本没有，但是已经列入开发计划
