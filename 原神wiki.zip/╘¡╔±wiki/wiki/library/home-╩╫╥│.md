# 原神wiki

<br>

![欢迎使用Genshin Impact Wiki！](amWiki/images/logo.png "欢迎使用原神Wiki！")  

### 欢迎使用 原神wiki!
—— **本wiki致力于让大家可以更简单、更便捷地了解关于原神的信息！**  

<a href="https://ys.mihoyo.com/" target="_blank">【原神官网】</a>
